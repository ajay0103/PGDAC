/*
Create a class Electricity bill with data members as customer number, 
		   customer name, units consumed and methods as follows:
		   (a). readData() - to read the values of data menbers. 
               (b).showData - to display the values of data members 
		   (c). computeBill() - to calculate and return electricity charges to be paid. 
		   Read customer object values, calculate electricity bill and display the values 
               following criteria.
			number of units charges
					< = 100 Rs.1.20
					for the next 200 units Rs. 2.00
					for the next 300 units Rs. 3.00
					for more Rs. 5.00      

*/




import java.util.Scanner;
class Customer{
        int customer_no,units_consumed;
        String customer_name;
        double bill;
        int a,b,c,d;
        Scanner sc =new Scanner(System.in);
               
           void readData() 
             {
               System.out.println("enter customer_no ::" );
               customer_no=sc.nextInt();
              
              System.out.println("enter units_consumed ::" );
               units_consumed=sc.nextInt();  

               System.out.println("enter customer_name::" );
                customer_name=sc.next();  
            }

      void showData(){
            System.out.println("enter customer_no ::" +customer_no);
            System.out.println("enter units_consumed ::" + units_consumed);   
            System.out.println(" enter units_consumed ::" +customer_name);
            }
      void computeBill(){
            if(units_consumed<=100)
            {
            bill = (units_consumed*1.20);
            System.out.println(" Customer_Bill ::" +bill);
            }

             else if(units_consumed>100 && units_consumed<=200 )
            {
            a =(units_consumed-100);
            b = (units_consumed-a);
            bill = ((b*1.2)+(a*2));
            System.out.println(" Cutomer_Bill ::" +bill);
            }

             else if(units_consumed>200 && units_consumed<=300)
            {
             a = (units_consumed-200);
             b =(units_consumed-100);
             c = (units_consumed-b);
            bill = ((c*1.2)+(b*2)+(a*3));
            System.out.println(" Cutomer_Bill ::" +bill);
            }
              else if(units_consumed>500)
            {
            a =(units_consumed-300);
            b = (units_consumed-200);
            c = (units_consumed-100);
            d = units_consumed-c;
             bill = ((d*1.2)+(c*2)+(b*3)+(a*5));
            System.out.println(" Cutomer_Bill ::" +bill);
            }
            
       }  

         public static void main(String args[])
{
          Customer c1 =new Customer();
           c1.readData();
           c1.showData();
           c1.computeBill();

}
}

/*
C:\Users\HP\Desktop\CORE-JAVA\Study Materials>java Customer
enter customer_no ::
1001
enter units_consumed ::
800
enter customer_name::
Ajay
enter customer_no ::1001
enter units_consumed ::800
 enter units_consumed ::Ajay
 Cutomer_Bill ::5820.0
*/