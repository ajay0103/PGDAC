/* Create a class Emp with data members 
		   emp no, emp name, emp designation, dept and salary,
		   date of joining and data methods as 
		   setData() (to set the values to data members) and 
	         displayData() (to display data members values to thescreen) 
		   create an employee instance and display its information.        
*/


import java.util.Scanner;
class Employee{
        int emp_no;
        double totsal;
        String emp_name,dept,emp_designation,datejoin;
        Scanner sc =new Scanner(System.in);
               
           void setData() 
             {
               System.out.print("enter Employee ID :" );
               emp_no=sc.nextInt();
              
              System.out.print("enter Date of join :" );
               datejoin=sc.next();  

               System.out.print(" enter emp_name:" );
               emp_name=sc.next();    

             System.out.println(" enter dept :");
               dept=sc.next();    

             System.out.println("enter totsal :");
             totsal=sc.nextDouble();    

              System.out.print("enter emp_designation ::");
             emp_designation=sc.next(); 
              
             
            }
           

           
      void displayData(){

            System.out.println("enter Emp ID :" +emp_no);
            System.out.println("enter Date of join :" +datejoin);   
            System.out.println(" enter emp_name:" +emp_name);
             System.out.println(" enter dept " +dept);
             System.out.println(" enter totsal:" +totsal);
             System.out.println(" enter  emp_designation" +emp_designation);
            }


         public static void main(String args[])
{
          Employee s1 =new Employee();
           s1.setData();
           s1.displayData();
}
}

/*
E:\PG-DAC\CORE-JAVA\ASSIGNMENTS\3\Assignment 3\Question1>java Employee
enter Employee ID :1002
enter Date of join :1/4/2008
 enter emp_name:Ajay
 enter dept :
R&D
enter totsal :
60000
enter emp_designation  :Engineer
enter Emp ID :1002
enter Date of join :1/4/2008
 enter emp_name:Ajay
 enter dept R&D
 enter totsal:60000.0
 enter  emp_designation ::Engineer
*/
