//6. Write a program to convert the temperature (a) from Celsius to Fahrenheit
import java.util.Scanner;
 class  CelsiusToFahrenheit{

	public static void main(String[] args) {
		float Fahrenheit, Celsius;
		Celsius =137;

		Fahrenheit = (9*Celsius/5)+32;
		System.out.printf("The temperture in  Fahrenheit:" +Fahrenheit);
		
		
	}

}

/*
C:\Users\HP\Desktop\Java Class Codes\Assignment1>java CelsiusToFahrenheit
The temperture in  Fahrenheit:278.6
*/