//from Fahrenheit to Celsius. (Hint: F=(9C/5+32))
import java.util.Scanner;
 class  CelsiusToFaht{

	public static void main(String[] args) {
		float Fahrenheit, Celsius;
		System.out.println("Enter temperture in   :");
		Scanner sc=new Scanner(System.in);
		Celsius =sc.nextFloat(); 

		Fahrenheit = (9*Celsius/5)+32;
		System.out.printf("The temperture in  Fahrenheit:" +Fahrenheit);
		
		
	}

}

/*

C:\Users\HP\Desktop\Java Class Codes\Assignment1>java CelsiusToFahrenheit
Enter temperture in   :
100
The temperture in  Fahrenheit:212.0

*/