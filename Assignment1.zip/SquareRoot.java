//4. Write a program to read value of A,B,C and find the roots of the quadric equation.
class SquareRoot {
		double a = 12, b = 5, c = 7;
		double r1, r2;
		double d = b * b - 4 * a * c;
               {

		if(d > 0) {
			r1 = (-b + Math.sqrt(d)) / (2 * a);
		        r2 = (-b - Math.sqrt(d)) / (2 * a);
		        System.out.print("r1 = %.2f" +r1);
                        System.out.print("r2= %.2f" ,+ r2);
		}
		else if(d == 0)
                {
		      r1 = r2 = -b / (2 * a);
                      System.out.print("r1 = r2 = %.2f;" + r1);
		}
		else
                   {
			double real = -b / (2 * a);
			double imaginary = Math.sqrt(-d) / (2 * a);

			System.out.print("r1 = %.2f+%.2fi",real, imaginary);
			System.out.print("r2 = %.2f-%.2fi",real, imaginary);
		    }
	}
}

/*
r1 = -0.21+0.73i
r2= -0.21-0.73i
*/