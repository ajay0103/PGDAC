//6. Write a program to convert the temperature (a) from Celsius to Fahrenheit
import java.util.Scanner;
 class  FahrenheitToCel{

	public static void main(String[] args) {
		float Fahrenheit, Celsius;
		System.out.println("Enter temperture in  Fahrenheit :");
		Scanner sc=new Scanner(System.in);
		Fahrenheit=sc.nextFloat();
                Celsius =((Fahrenheit - 32)*5)/9;  
		
		System.out.printf("The temperture in Celsius :" +Celsius);
		
		
	}

}

/*
C:\Users\HP\Desktop\Java Class Codes\Assignment1>java FahrenheitToCelsius
Enter temperture in  Fahrenheit :
100
The temperture in Celsius :37.77778
*/
