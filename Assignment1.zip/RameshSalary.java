/*
8. Ramesh’s basic salary is input through the keyboard. His dearness allowance is 40% 
of basic salary, and house rent allowance is 20% of basic salary. Write a program to 
calculate his gross salary
*/



import java.util.Scanner;
class RameshSalary {
	public static void main(String[]args) {
		float basicSal,da,hra;
                float GrossSalary;

		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Salary of Ramersh: ");
		basicSal =sc.nextFloat();

		da=(basicSal*40)/100;
                System.out.println("The Dearness Allowance : " +da);
                

                hra=(basicSal*20)/100;
	        System.out.println("The House Rant Allowance : " +hra);
                

		GrossSalary = (basicSal + da + hra);
                System.out.println("GrossSalary of Ramesh : " +GrossSalary);
                

		}
	

}

/*
C:\Users\HP\Desktop\Java Class Codes\Assignment1>java RameshSalary
Enter the Salary of Ramersh:
20000
The Dearness Allowance : 8000.0
The House Rant Allowance : 4000.0
GrossSalary of Ramesh : 32000.0
*/
