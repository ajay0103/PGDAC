//5. Write a program to any radius and print the area of circle.

import java.util.Scanner;
 class AreaOfCircle {

	public static void main(String[] args) {
		float Area, radius,pi;
		System.out.println("Enter Radius Of Circle");
		Scanner sc=new Scanner(System.in);
		radius=sc.nextFloat();
		pi= (float) Math.PI;
		Area=pi*radius*radius;
		System.out.printf("Area of circle= %.3f\n",Area);
		
		
	}

}


/*
C:\Users\HP\Desktop\Java Class Codes\Assignment1>java AreaOfCircle
Enter Radius Of Circle
6
Area of circle= 113.097
*/