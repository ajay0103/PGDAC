//Fahrenheit to Celsius. (Hint: F=(9C/5+32))

import java.util.Scanner;
 class  FahrenheitToCelsius{

	public static void main(String[] args) {
               float Fahrenheit,Celsius;
		Fahrenheit = 100 ;
		
                Celsius =((Fahrenheit - 32)*5)/9;  
		
		System.out.printf("The temperture in Celsius :" +Celsius);
		
		
	}

}

/*

C:\Users\HP\Desktop\Java Class Codes\Assignment1>java FahrenheitToCelsius
The temperture in Celsius :37.77778

*/