/*
7. Write a program to swap value of two variables without using arithmetic operators 
and third variable.
*/



import java.util.Scanner;

class SwapBitWiseXOR{
     public static void main(String[] args)
     {
      int x,y;
      Scanner sc = new Scanner(System.in);
      System.out.println("Enter First number :");
      x= sc.nextInt();
      System.out.println("first number" +x);     

      System.out.println("Enter second number :");
      y= sc.nextInt();
      System.out.println("second number" +y);
       
        x = x ^ y;
        y = x ^ y;
        x = x ^ y;
     
      System.out.println("first number after Swap :" +x);

      System.out.println("second number after swap :" +y);
       
     
     }
}
/*

C:\Users\HP\Desktop\Java Class Codes\Assignment1>java SwapBitWiseXOR
Enter First number :
12
first number12
Enter second number :
123
second number123
first number after Swap :123
second number after swap :12

*/