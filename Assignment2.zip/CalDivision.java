/*
. The marks obtained by a student in 5 different subjects are input through the 
keyboard. The student gets a division as per the following rules:
Percentage above or equal to 75 – Honors, Percentage above or equal to 60 – First 
Division Percentage between 50 and 59 – Second Division, Percentage between 40 and 49 –
Third Division Percentage less than 40 – Fail,  Write a program to calculate the division obtained by the student.
*/


import java.util.Scanner;
class CalDivision{
     public static void main(String[] args)
     {
      double prcent;
      Scanner sc = new Scanner(System.in);
      System.out.println("Enter percentage ::");
      prcent = sc.nextDouble();
   
      if(prcent >= 75){
       System.out.println("Division Obtained by Student :: Honors");
       }
       else if(prcent >= 60 && prcent < 75){
        System.out.println("Division Obtained by Student :: First Division");
       }
       else if(prcent >= 50 && prcent < 59){
        System.out.println("Division Obtained by Student :: second Division");
        }
       else if(prcent>=40 && prcent < 49){
        System.out.println("Division Obtained by Student :: Third Division");
        }
       else if(prcent<40){
       System.out.println("Student is failed");
        }
        else {
          System.out.println("Failed!");
         }
        
      
     }
}

/*
C:\Users\HP\Desktop\CORE-JAVA\ASSIGNMENTS\2\Assignment2\Question10>java CalDivision
Enter percentage ::
67
Division Obtained by Student :: First Division
*/