//Write a program in Java to print Fibonacci series upto given number? Write both 
//		   Iterative and Recursive version											*/




import java.util.Scanner;
class FiboIter 
{
  	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter a number= ");
		int n=sc.nextInt();
    		int a=0, b=1;
    		System.out.println("Fibonacci Series till " +n+ " terms:");

	
    		for (int i = 1; i <= n; ++i) 
		{
      		System.out.print(a+" ");
      		int c=a+b;
      		a=b;
     			b=c;
    		}
  	}
}
/*

E:\PG-DAC\CORE-JAVA\ASSIGNMENTS\2\Assignment2\Question8>java FiboIter
Enter a number= 10
Fibonacci Series till 10 terms:
0 1 1 2 3 5 8 13 21 34
E:\PG-DAC\CORE-JAVA\ASSIGNMENTS\2\Assignment2\Question8>


*/