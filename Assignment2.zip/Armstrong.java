//Write a Java program to check if a number is Armstrong or not?

import java.util.Scanner;

class Armstrong{
     public static void main(String[] args)
     {
     int n,sum=0,temp,rem,res=0;
      Scanner sc = new Scanner(System.in);
      System.out.println("Enter First number :");
      n= sc.nextInt();
      System.out.println("first number :" +n);
      
      temp = n;
      while(temp !=0)
      {
       rem = temp %10;
       res += Math.pow(rem,3);
       temp=temp/10;
      }
      if(res == n){
         System.out.println("Armstrong number");
         }
      else
{      
       System.out.println("not Armstrong number");  
        }
     
     }
}


/*
C:\Users\HP\Desktop\CORE-JAVA\ASSIGNMENTS\2\Assignment2\Question6>java  Armstrong
Enter First number :
371
first number :371
Armstrong number
*/