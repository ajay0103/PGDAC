/*While purchasing certain items, a discount of 10% is offered if the quantity purchased 
            is more than 1000. If quantity and price per item are input through the keyboard, write 
        a program to calculate the total expenses 										

 */

package demo.Assignment;

import java.util.Scanner;

public class TotalExpense {
	public static void main(String[] arg) 
	{

		int pp;
		int quantity;
		int bill=0;
		double discount=0;
		double totalbill=0;
   		Scanner sc = new Scanner(System.in);

		System.out.print("Enter Quantity of Items :: ");
		pp=sc.nextInt();

		System.out.print("Enter Price per item :: "); 		
		quantity=sc.nextInt();

		bill=pp*quantity;
		discount=0.10*pp*quantity;
		totalbill=bill-discount;

		if(bill>1000)
		{    
     			System.out.println("Total expense = "+totalbill);
		}

		else if(bill<=1000)
		{
     			System.out.println("Total expense = "+bill);
		}
  	}
}

/*
Enter Quantity of Items :: 1000
Enter Price per item :: 90
Total expense = 81000.0
 */
