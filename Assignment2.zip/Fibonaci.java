// Write a program in Java to print Fibonacci series upto given number? Write both 
//		   Iterative and Recursive version													*/

import java.util.Scanner;
class Fibonaci
{
	static void fibo(int c, int a, int b)
	{
	 int sum;
	 if(c>0)
	 {
	 	sum=a+b;
	 	a=b;
	 	b=sum;
	 	System.out.print(sum+" ");
	 	fibo(c-1,a,b);
	 }
	}
public static void main(String args[])
	{
	 int a=0,b=1,sum,c;
	 System.out.print("Enter the number= ");
	 Scanner sc=new Scanner(System.in);
	 c=sc.nextInt();
	 System.out.print(a+" "+b+" ");
	 fibo(c-2,a,b);
	}
}


/*
E:\PG-DAC\CORE-JAVA\ASSIGNMENTS\2\Assignment2\Question5>java Fibonaci
Enter the number= 10
0 1 1 2 3 5 8 13 21 34
E:\PG-DAC\CORE-JAVA\ASSIGNMENTS\2\Assignment2\Question5>

*/