// Write a program to find if a number is power of 2 in Java		*/

//Write a program to find if a number is power of 2 in Java	
import java.util.Scanner;
class PowerOfTwo
{
	public static void main(String args[])
     {
	 Scanner sc=new Scanner(System.in);
	 System.out.print("Enter a number= ");
	 int n=sc.nextInt();
	 
	 int val=(n & (n-1));
		 
	 if(val==0)
	    {
 	 	 System.out.println("Number is a power of 2");
	    }

	 else
	    {
	 	 System.out.println("Number is not a power of two");
	    }

     }
}


/*

E:\PG-DAC\CORE-JAVA\ASSIGNMENTS\2\Assignment2\Question4>java PowerOfTwo
Enter a number= 12
Number is not a power of two
*/
