/*
8. If his basic salary is less than Rs. 1500, then HRA=10% of basic salary and DA=25% 
of basic. If his salary is either equal to or above Rs. 1500, then HRA=Rs. 500 and 
DA=50% of basic. If the employee’s salary is input through the keyboard write a 
program to find his gross salary.
*/

import java.util.Scanner;

class GrossSal{
     public static void main(String[] args)
     {
      int n,p,dis=0,totexp,G;
      Scanner sc = new Scanner(System.in);
      System.out.println("Enter number of unit Quantity:");
       n = sc.nextInt();
     
       System.out.println("enter the price per unit");
       p = sc.nextInt();
      
       totexp = (n * p);

       System.out.println("total expences : " +totexp);
       

      if(totexp > 1000){
         dis = (totexp*10)/100;
         System.out.println("applicable discount : " +dis);
         }
       else
       {      
       System.out.println("no discount");  
        }
        G = totexp - dis;
       System.out.println("Gross Salary =" + G  );
     }
}


/*
C:\Users\HP\Desktop\CORE-JAVA\ASSIGNMENTS\2\Assignment2\Question7>java GrossSal
Enter number of unit Quantity:
200
enter the price per unit
34
total expences : 6800
applicable discount : 680
Gross Salary =6120
*/

