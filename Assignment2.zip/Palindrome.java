//3. Write a Java program to check if a number is palindrome or not

import java.util.Scanner;

class Palindrome{
     public static void main(String[] args)
     {
     int n, sum=0,rem,temp;
      Scanner sc = new Scanner(System.in);
      System.out.println("Enter First number :");
      n= sc.nextInt();
      System.out.println("first number :" +n);  
      temp=n;

      while (n>0){
      rem = n % 10;
      sum = (sum*10) + rem;
      n = n/10;
      }

      if(temp == sum){
         System.out.println("palindrome number");
         }
      else
{      
       System.out.println("not palindrome number");  
        }
     
     }
}

/*
C:\Users\HP\Desktop\CORE-JAVA\ASSIGNMENTS\2\Assignment2\Question3>java Palindrome
Enter First number :
121
first number :121
palindrome number
*/