//1. Write a program in Java to check if a number is even or odd
import java.util.Scanner;

class EvenOdd{
     public static void main(String[] args)
     {
      int a,b;
      Scanner sc = new Scanner(System.in);
      System.out.println("Enter First number :");
      a= sc.nextInt();
      System.out.println("first number :" +a);  
   
      if(a%2 ==0)
      {
      System.out.println("Even number");
      }
      else{
      System.out.println("odd number" );
      }
       
       
     
     }
}

/*
C:\Users\HP\Desktop\CORE-JAVA\ASSIGNMENTS\2\Assignment2\Question1>java EvenOdd
Enter First number :
123
first number123
odd number
*/