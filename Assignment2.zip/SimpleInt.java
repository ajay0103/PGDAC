import java.util.Scanner;

class CompoundInt{
     public static void main(String[] args)
     {
      double n,p=0;
      double r ,CI;
   
      Scanner sc = new Scanner(System.in);
      System.out.println("Enter amount ::");
       p = sc.nextDouble();
     
       System.out.println("Enter rate");
       r = sc.nextDouble();
       
       System.out.println("Enter time period in years ");
       n = sc.nextDouble();

        CI = p*(Math.pow((1+ r/100), n));
       
       System.out.println("total CI : " +CI);
      
     }
}

/*
C:\Users\HP\Desktop\CORE-JAVA\ASSIGNMENTS\2\Assignment2\Question9>java CompoundInt
Enter amount ::
10000
Enter rate
5
Enter time period in years
8
total CI : 14774.55443789063
*/