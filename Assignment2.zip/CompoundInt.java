import java.util.Scanner;

class SimpleInt{
     public static void main(String[] args)
     {
      double n,p=0,r ,SI;
      Scanner sc = new Scanner(System.in);
      System.out.println("Enter amount ::");
       n = sc.nextDouble();
     
       System.out.println("Enter rate");
       r = sc.nextDouble();
       
       System.out.println("Enter time period in years ");
       p = sc.nextDouble();
      
       SI= (n * p * r)/100;

       System.out.println("total SI : " +SI);
      
     }
}

/*
C:\Users\HP\Desktop\CORE-JAVA\ASSIGNMENTS\2\Assignment2\Question9>java SimpleInt
Enter amount ::
2000
Enter rate
10
Enter time period in years
4
total SI : 800.0
*/